<link rel="stylesheet" href="./css/style-desktop.css">
<link rel="stylesheet" href="./css/style-medium.css">
<link rel="stylesheet" href="./css/style-mobile.css">
